# B Closed the Deal — Southwest Florida Real Estate
Static website for free Render hosting. Publish directory: `.`. Build command: `echo 'Static site ready'`.
Wix form remains the linked inquiry form, hosted separately by Wix. Google Sheets automatic sync must be configured separately.
Do not change domain DNS until deployment works and Render provides DNS instructions.
